create or replace package x
as
    function is_prime(n number) return boolean;
    procedure test;
end;
/
show errors


create or replace package body  x
as
    procedure p(s varchar2) is begin dbms_output.put_line(s); end p;
    procedure p(n number  ) is begin dbms_output.put_line(n); end p;
    procedure p(d date    ) is begin dbms_output.put_line(d); end p;
    function is_prime(n number) return boolean
    is
    begin
        case 
            when  n is null      then return null;
            when  mod(n,1) !=0   then return null;
            when  n < 2          then return false;
            when  n = 2          then return true;
            else                      null;
        end case;
        for i in 2..trunc(n/2) loop
            ---p(to_char(n) ||' ? '||to_char(i) || ' remainder ' || to_char(mod(n,i))    );
            if mod(n,i) = 0 then return false; end if;
        end loop;
        return true;
    end is_prime;
    procedure test
    is
    begin
        if   is_prime(null)   then   p('null is prime');   else   p('null is NOT prime');   end if;
        if   is_prime(-1)     then   p('-1   is prime');   else   p('-1   is NOT prime');   end if;
        if   is_prime(2.2)    then   p('2.2  is prime');   else   p('2.2  is NOT prime');   end if;
        for i in 1..23 loop
            null;
            if   is_prime(i)   then   p(to_char(i) ||' is prime');  else   p(to_char(i) ||' is NOT prime');   end if;
        end loop;
    end test;
end;
/
show errors

exec x.test
